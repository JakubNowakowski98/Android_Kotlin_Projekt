package org.projekt.masterand

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import org.projekt.masterand.gamescreen.GameScreen
import org.projekt.masterand.startscreen.StartScreen

@Composable
fun SetupNavGraph(navController: NavHostController){
    NavHost(
        navController = navController,
        //startDestination określa co będzie początkowym ekranem - "first_screen" zdefiniowano w pliku Screen.kt
        startDestination = "start_screen" ){

        composable(route = Screen.Start.route){
            //Co ma się zdarzyć po przejściu do tego ekranu
            StartScreen(navController = navController)
        }

        composable(route = Screen.Game.route + "/{colorNum}", enterTransition = {
            fadeIn() + slideIntoContainer(towards = AnimatedContentTransitionScope.SlideDirection.Companion.Left, animationSpec = tween(700))
        }, exitTransition = {
            fadeOut() + slideOutOfContainer(towards = AnimatedContentTransitionScope.SlideDirection.Companion.Right, animationSpec = tween(700))
        }){ backStackEntry ->
            val colorNum = backStackEntry.arguments?.getString("colorNum")?.toInt()
            GameScreen(navController = navController, colorNum = colorNum?: 6)
        }
    }
}