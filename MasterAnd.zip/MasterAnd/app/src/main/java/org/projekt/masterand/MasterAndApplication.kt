package org.projekt.masterand

import android.app.Application

class MasterAndApplication : Application() {
}