package org.projekt.masterand

sealed class Screen(val route: String) {
    object Start: Screen(route = "start_screen")
    object Game: Screen(route = "game_screen")
}