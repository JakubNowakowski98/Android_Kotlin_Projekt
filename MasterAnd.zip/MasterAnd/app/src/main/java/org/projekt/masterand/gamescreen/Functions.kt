package org.projekt.masterand.gamescreen

import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.graphics.Color

fun selectNextAvailableColor(availableColors: List<Color>, selectedColors: List<Color>, buttonNum: Int): Color {
    var selectedColorIndexInc = availableColors.indexOf(selectedColors[buttonNum])
    var found = false;
    while(!found){
        selectedColorIndexInc++
        if(selectedColorIndexInc > availableColors.count()-1){
            selectedColorIndexInc = 0
        }
        if(!selectedColors.contains(availableColors[selectedColorIndexInc])){
            found = true
        }
    }
    return availableColors[selectedColorIndexInc]
}

fun selectRandomColors(availableColors: List<Color>): List<Color> {
    val c = availableColors.toMutableList()
    val c1 = c.random()
    c.remove(c1)
    val c2 = c.random()
    c.remove(c2)
    val c3 = c.random()
    c.remove(c3)
    val c4 = c.random()
    return listOf(c1, c2, c3, c4)
}

fun checkColors(selectedColors: List<Color>, correctColors: List<Color>, notFoundColor: Color): SnapshotStateList<Color> {
    val feedbackColors: SnapshotStateList<Color> = SnapshotStateList()
    for (i in correctColors.indices) {
        if (correctColors[i] == selectedColors[i]) {
            feedbackColors.add(Color.Red)
        } else if (selectedColors[i] in correctColors) {
            feedbackColors.add(Color.Yellow)
        } else {
            feedbackColors.add(notFoundColor)
        }
    }
    return feedbackColors
}
