package org.projekt.masterand.gamescreen

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FabPosition
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import org.projekt.masterand.Screen

data class GameRowInfo(
    val selectedColors: MutableList<Color> = mutableStateListOf(Color.White, Color.White, Color.White, Color.White),
    val feedbackColors: MutableList<Color> = mutableStateListOf(Color.White, Color.White, Color.White, Color.White)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameScreen(navController: NavController, colorNum: Int) {

    val score = remember { mutableIntStateOf(0) }

    val availableColors =
        listOf(Color.Red, Color.Green, Color.Blue, Color.Yellow, Color.Magenta, Color.Cyan, Color.LightGray, Color.Gray, Color.DarkGray, Color.Black).take(colorNum)
    val correctColors = remember {
        mutableStateOf(selectRandomColors(availableColors))
    }
    val gameRows = remember { mutableStateListOf(GameRowInfo()) }

    var gameFinished by remember { mutableStateOf(false) }


    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { navController.navigate(route = Screen.Start.route) },
                shape = CircleShape
            ) {
                Icon(Icons.Filled.ArrowBack, "Powrót")
            }
        },
        floatingActionButtonPosition = FabPosition.Center
    ) { innerPadding ->
        Column(horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxSize().padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(text = "Your score: ${score.intValue}", fontSize = 42.sp)
            gameRows.forEachIndexed { index, rowData ->
                GameRow(
                    selectedColors = rowData.selectedColors,
                    feedbackColors = rowData.feedbackColors,
                    isClickable = index == gameRows.lastIndex && !gameFinished,
                    onSelectColorClick = { buttonIndex ->
                        if (index == gameRows.lastIndex && !gameFinished) {
                            val newColor = selectNextAvailableColor(
                                availableColors,
                                rowData.selectedColors,
                                buttonIndex
                            )
                            rowData.selectedColors[buttonIndex] = newColor
                        }
                    },
                    onCheckClick = {
                        if (index == gameRows.lastIndex && !gameFinished) {
                            val newFeedbackColors = checkColors(
                                rowData.selectedColors.toList(),
                                correctColors.value,
                                Color.White
                            )
                            rowData.feedbackColors.clear()
                            rowData.feedbackColors.addAll(newFeedbackColors)
                            score.intValue++
                            if (rowData.feedbackColors.all { it == Color.Red }) {
                                gameFinished = true
                            } else {
                                gameRows.add(GameRowInfo())
                            }
                        }
                    }
                )
            }
            Spacer(modifier = Modifier.height(16.dp))

            AnimatedVisibility(visible = gameFinished, enter = slideInVertically() + expandHorizontally() + fadeIn(
                initialAlpha = 0.3f
            ) ) {
                Button(
                    onClick = {
                        score.intValue = 0
                        gameRows.clear()
                        gameRows.add(GameRowInfo())
                        correctColors.value = selectRandomColors(availableColors)
                        gameFinished = false
                    },
                    modifier = Modifier
                        .height(50.dp)
                        .width(250.dp)
                ) {
                    Text(
                        text = "Start over",
                        fontSize = 20.sp
                    )
                }
            }
        }
    }
}
