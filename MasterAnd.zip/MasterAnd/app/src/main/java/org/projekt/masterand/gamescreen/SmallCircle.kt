package org.projekt.masterand.gamescreen

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.EaseInCubic
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@Composable
fun SmallCircle(color: Color, index: Int) {
    val animateColor by remember { mutableStateOf(false).apply { value = true } }
    val animatedColor by animateColorAsState(
        if (animateColor)
            color
        else
            Color.White,
        animationSpec = tween(300, delayMillis = index * 300, easing = EaseInCubic),
        label = "feedback for $index"
    )

    Box(modifier = Modifier
        .size(20.dp)
        .clip(CircleShape)
        .background(animatedColor)
        .border(2.dp, MaterialTheme.colorScheme.outline, CircleShape)
    ) {

    }
}

@Preview
@Composable
fun SmallCirclePreview() {
    SmallCircle(color = Color.Magenta, index = 0)
}
